<div class="kad-post-navigation clearfix">
        <div class="alignleft kad-previous-link">
        <?php previous_post_link('%link', __('Previous Post', 'virtue')); ?> 
        </div>
        <div class="alignright kad-next-link">
        <?php next_post_link('%link', __('Next Post', 'virtue')); ?> 
        </div>
 </div> <!-- end navigation -->
 